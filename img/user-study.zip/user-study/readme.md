The "user-study" folder contains the materials used in the user study:
- The "time.xlsx" records the time used by each participant for each task

- The "ratings.xlsx" records the ratings of the questionnaire

- The "replication" fold contains the real-world GIF to be replicated and the GIFs replicated by our system. 

- The "free-form" folder contains user-generated GIFs in the free-form tasks and each user's work is documented in their respective folder named. 

- The "preview-based" folder contains GIFs users created in the part II. 

- The "dataset" folder contains the six datasets we used in the user study. 

